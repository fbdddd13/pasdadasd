 package su.sacura.features.modules.impl.movement.freelook;
 
 public class FreeLookState {
   public static boolean active = false;
   
   public static float yaw;
   
   public static float pitch;
 }


