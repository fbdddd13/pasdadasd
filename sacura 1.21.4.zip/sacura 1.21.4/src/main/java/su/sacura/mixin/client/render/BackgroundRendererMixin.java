package su.sacura.mixin.client.render;

import net.minecraft.client.render.BackgroundRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.Fog;
import net.minecraft.client.render.FogShape;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import su.sacura.Sacura;
import su.sacura.events.render.FogEvent;
import su.sacura.features.modules.impl.render.NoOverlayModule;
import su.sacura.util.impl.render.providers.ColorProvider;

@Mixin({BackgroundRenderer.class})
public class BackgroundRendererMixin {
    @Inject(method = {"getFogModifier(Lnet/minecraft/entity/Entity;F)Lnet/minecraft/client/render/BackgroundRenderer$StatusEffectFogModifier;"}, at = {@At("HEAD")}, cancellable = true)
    private static void onGetFogModifier(Entity entity, float tickDelta, CallbackInfoReturnable<Object> info) {
        if (((NoOverlayModule)Sacura.getInstance().getModuleManager().getModule(NoOverlayModule.class)).enable && ((Boolean)((NoOverlayModule)Sacura.getInstance().getModuleManager().getModule(NoOverlayModule.class)).delete.getValueByName("Плохие эффекты").get()).booleanValue())
            info.setReturnValue(null);
    }

    @Inject(method = {"getFogColor"}, at = {@At("HEAD")}, cancellable = true)
    private static void getFogColorHook(Camera camera, float tickDelta, ClientWorld world, int clampedViewDistance, float skyDarkness, CallbackInfoReturnable<Vector4f> cir) {
        FogEvent event = new FogEvent();
        Sacura.getInstance().getEventBus().post(event);
        if (event.isCancelled()) {
            int color = event.getColor();
            cir.setReturnValue(new Vector4f(ColorProvider.redf(color), ColorProvider.greenf(color), ColorProvider.bluef(color), ColorProvider.alphaf(color)));
        }
    }

    @Inject(method = {"applyFog"}, at = {@At("HEAD")}, cancellable = true)
    private static void modifyFog(Camera camera, BackgroundRenderer.FogType fogType, Vector4f vector4f, float viewDistance, boolean thickenFog, float tickDelta, CallbackInfoReturnable<Fog> cir) {
        FogEvent event = new FogEvent();
        Sacura.getInstance().getEventBus().post(event);
        if (event.isCancelled()) {
            int color = event.getColor();
            // Исправлено: field_36351 -> FogShape.CYLINDER
            cir.setReturnValue(new Fog(2.0F, event.getDistance(), FogShape.CYLINDER, ColorProvider.redf(color), ColorProvider.greenf(color), ColorProvider.bluef(color), ColorProvider.alphaf(color)));
        }
    }
}